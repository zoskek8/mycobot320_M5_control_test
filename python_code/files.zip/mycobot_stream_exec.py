"""
스트리밍 실행 루프 (6차 분할)
================================================================================

mycobot_path_editor.py의 execute_path()에서 **실시간 데드라인이 있는 부분**만
뽑아냈다: 통신 주기 자동보정(calibrate_dispatch_period)과 브레이크 없는 스트리밍
전송 루프(run_streaming_dispatch, 적응형 재보정 포함).

이 모듈도 mycobot_curve_math.py와 같은 이유로 분리했다 - GUI(self)에 의존하지
않는 순수 로직만 모아서, 실수(예: `def` 누락 같은)를 눈에 띄게 만들고 재사용/
검증을 쉽게 한다. 자세한 배경은 mycobot_curve_math.py 모듈 docstring 참고.

**실행속도 차이는 없다** - 파일 분할은 조직 문제고, import한 함수를 부르는 것과
같은 파일의 메서드를 부르는 것은 파이썬 수준에서 비용이 사실상 같다.
"""

import time
import math
import gc
from collections import deque
import numpy as np

from mycobot_kinematics import active_indices, fast_send_angles, joint_offset_correction

# ┌─ 스트리밍(브레이크 없음) 모드 설정 ────────────────────────────────────────┐
# │ fresh_mode(1)은 이전 명령을 버리고 최신 명령만 즉시 실행 -> 웨이포인트마다  │
# │ 감속하지 않음. 대신 목표에 도달하기 전에 다음 목표를 받으므로 코너를 조금  │
# │ 잘라먹는데, 그 양은 웨이포인트 간격에 비례하므로 간격을 촘촘히 하면 오차가 │
# │ 작게 유지된다.                                                             │
# │ [실측으로 밝혀진 사실] 한 사이클의 하한은 시리얼 왕복이 아니라 ATOM        │
# │ 펌웨어의 프레임 소화속도이며 약 28ms(MIN_DISPATCH_PERIOD_SEC)다.           │
# │ 읽기(get_coords/get_angles)는 ATOM 펌웨어 차원에서 1회당 약 20ms가 걸린다  │
# │ (Elephant Robotics 공식 이슈 #53: "읽기는 50Hz가 최대"). 매 사이클 2회     │
# │ 읽으면 40ms 이상이 측정에만 소모되어 움직임 자체가 끊긴다 -> 기본은        │
# │ '단방향'(쓰기 전용).                                                       │
# └─────────────────────────────────────────────────────────────────────────────┘
MIN_DISPATCH_PERIOD_SEC = 0.028   # 전송 주기 하한 (펌웨어 소화 한계 보호).
                                  #   실측: 22ms에서 밀림 1.7~1.8초 발생 -> 로봇이 못 따라감.

# ┌─ [패치 3] 속도 파라미터 모순 제거 ────────────────────────────────────────┐
# │ 이전에는 세 값이 서로 어긋나 있었다.                                      │
# │   · dispatch_period = max(0.028, STREAM_STEP_MM/STREAM_TCP_SPEED_MMS)     │
# │     -> 2/90=0.0222 < 0.028 이라 STREAM_TCP_SPEED_MMS(90)는 항상 무시됨.   │
# │        즉 죽은 파라미터였고, 실행 후 경고문 "STREAM_TCP_SPEED_MMS를       │
# │        낮추세요"를 따라해도 아무 일도 일어나지 않았다.                    │
# │   · GUI 표시는 STREAM_STEP_MM/0.044 = 45mm/s 라고 알려주는데              │
# │        실제 속도는 2/0.028 = 71mm/s 였다 (Figure 3 실측 68mm/s).          │
# │                                                                          │
# │ 이제 손잡이는 STREAM_TCP_SPEED_MMS 하나다. 간격과 주기는 여기서 유도한다.│
# └──────────────────────────────────────────────────────────────────────────┘
STREAM_TCP_SPEED_MMS = 35   # ★ 목표 TCP 속도 - 스트리밍 속도는 오직 이 값으로만 조절한다.
                            #   68mm/s에서 추종지연 0.25~0.4s가 관측되어 낮춰 잡음.
                            #   높일수록 지연/코너컷이 커지고, 낮출수록 웨이포인트가 늘어
                            #   검증 시간이 길어진다. 40~70 사이에서 실험할 것.
                            #
                            #   [9차 세션, §26 후속] 45에서도 급커브 곡선의 특정 구간
                            #   (방향전환이 급한 곳)에서 속도 프로파일 오차가 후반부에
                            #   크게 튀는 게 관측됐다 - 요구 각속도가 서보 추종한계에
                            #   부딪히는 것으로 §26에서 이미 확인된 것과 같은 메커니즘.
                            #   전체 속도를 낮추면 여유 있던 구간보다 한계에 가까웠던
                            #   구간이 비례해서 더 크게 개선될 것으로 기대. 40~70 권장
                            #   범위 밖(35)이라 실기로 개선 여부를 반드시 확인할 것 -
                            #   효과 없으면 40으로, 그래도면 되돌릴 것(45).

# 웨이포인트 간격: 주기가 하한(28ms)에 붙어 있다는 전제로 목표속도에서 역산.
#   간격이 너무 촘촘하면(<0.5mm) 검증이 무거워지고, 너무 성기면(>6mm) 코너를 잘라먹는다.
STREAM_STEP_MM = float(min(6.0, max(0.5, STREAM_TCP_SPEED_MMS * MIN_DISPATCH_PERIOD_SEC)))

# ┌─ [6차] "정확도를 유지하면서 더 빠르게" - 간격을 '실제' 사이클에 맞춘다 ────┐
# │ 위 STREAM_STEP_MM은 사이클이 하한 28ms에 붙어 있다고 **가정**하고 만든    │
# │ 값이다. 그런데 '매번 실측' 모드는 매 사이클 get_angles()를 한 번 더 하고, │
# │ 그 읽기가 펌웨어 차원에서 ~20ms라 실제 사이클이 33ms 언저리로 나온다.     │
# │                                                                          │
# │ TCP 속도 = 간격 / 실제사이클 이므로:                                     │
# │     1.26mm / 33ms = 38mm/s   <- 목표 45가 아니라 38이 나오던 이유         │
# │ (실측 status.txt: "실측 33±4ms -> TCP 약 38mm/s" 와 정확히 일치)          │
# │                                                                          │
# │ 즉 느린 원인은 로봇이 못 따라가서가 아니라, **간격을 실제보다 짧은 주기   │
# │ 기준으로 잡아서** 애초에 목표속도가 나올 수 없는 조합이었던 것이다.       │
# │ 간격을 실제 사이클 기준으로 키우면 사이클 수를 늘리지 않고 속도만 오른다  │
# │ - 통신을 더 몰아치는 게 아니므로 밀림도 늘지 않는다.                      │
# │                                                                          │
# │ [정확도에 미치는 영향] 간격 1.26 -> 1.49mm (1.18배). 코너컷은 간격에      │
# │ 비례하므로 형상오차(cross-track)가 최대 그만큼 커질 수 있다. 반대로       │
# │ 속도는 38->45mm/s로 18% 오른다. 원치 않으면 아래 스위치를 False로 두면   │
# │ 예전 동작 그대로다.                                                       │
# └──────────────────────────────────────────────────────────────────────────┘
STEP_MATCHES_REAL_CYCLE = True     # False면 6차 이전 동작(28ms 가정)으로 되돌아감
# 측정모드별 '실제로 관측된' 사이클 시간(초). 캘리브레이션 로그(사이클바닥/실측)에서
# 온 값이며, 환경이 바뀌면 실행 후 상태줄의 '실측 NNms'를 보고 갱신할 것.
MEASURE_CYCLE_SEC = {
    "none": MIN_DISPATCH_PERIOD_SEC,   # 읽기 없음 - 펌웨어 하한이 그대로 사이클
    "full": 0.033,                     # 매번 실측 - get_angles() 왕복이 더해짐
}

# ┌─ [9차 세션, §25] 스파이크 흡수 전략 - 실기 검증 완료, 채택 ────────────────┐
# │ 배경: 사이클 리듬(§25)의 정확한 원인(GC 아님, Logitech 리시버 아님 -    │
# │ 둘 다 확인됨)은 못 찾았지만, "원인을 몰라도 주기 자체를 스파이크보다    │
# │ 넉넉히 잡으면 흡수된다"는 전략은 원인과 무관하게 유효했다.              │
# │                                                                          │
# │ [실기 결과, 2026-08-24] 목표주기 48ms 적용 후:                          │
# │   - 주기미달 15% -> 0%, 사이클 47.2~48.9ms 좁은 띠로 수렴                │
# │   - cross-track 평균 1.54->1.50mm, 최대 5.90->5.22mm (거의 무손실,      │
# │     오히려 근소 개선 - 간격이 1.45배 커졌는데도 §17.5 비례관계로        │
# │     추정했던 정확도 악화는 일어나지 않았다)                             │
# │   - 진짜 대가: 관절 추종지연(τ)이 전 관절 고르게 +20ms 안팎 증가        │
# │     (J1 200->223ms, J4 196->224ms 등) - 초당 명령 개수가 30->21개로     │
# │     줄어 보정 빈도 자체가 낮아진 게 원인. 이 정도는 감수하기로 결정.    │
# │                                                                          │
# │ 이후 False로 되돌리고 싶으면(예: τ 증가가 실사용에서 체감되면) 아래     │
# │ 한 줄만 바꾸면 된다 - 다른 코드는 안 건드려도 됨.                       │
# └──────────────────────────────────────────────────────────────────────────┘
ABSORB_SPIKES_TEST = True         # [채택됨] False로 바꾸면 예전(주기미달 있는) 동작으로 복귀
ABSORB_TARGET_PERIOD_SEC = 0.048  # 실측 스파이크(최대 51.8~55.4ms)를 덮는 목표주기

# 실제 전송 주기: 위 클램프에 걸린 경우에도 목표속도가 지켜지도록 다시 계산.
STREAM_DISPATCH_PERIOD_SEC = max(MIN_DISPATCH_PERIOD_SEC,
                                 STREAM_STEP_MM / max(1.0, STREAM_TCP_SPEED_MMS))

STREAM_SEND_SPEED = 100     # send_angles에 넘길 속도값 (항상 앞서가도록 높게)
# [6차 최종] 시작가속램프(STREAM_RAMP_SEC/STREAM_RAMP_START_FACTOR)는 제거했다.
# "0→목표속도 순간점프가 추종지연(τ)의 원인이니 서서히 가속하면 개선될 것"이라는
# 가설로 도입했었는데, 서로 다른 곡선 2개에서 A/B 비교한 결과 둘 다 **정반대**로
# 나왔다(램프 ON일 때 τ가 오히려 컸다: 280ms vs 180ms, 280ms vs 210ms - 두 번
# 다 OFF가 이김). 램프 구간 자체의 가감속 과도응답이 새로운 지연을 만드는
# 쪽이 맞았던 것으로 결론내고, GUI 토글과 함께 기능 자체를 걷어냈다. 이제
# run_streaming_dispatch는 처음부터 끝까지 dispatch_period로 등속 전송한다.

# ┌─ [6차 신규] 실시간 적응형 재보정 ──────────────────────────────────────────┐
# │ 그동안 "정지캘리브와 실행중 평균 사이의 격차"를 고정 상수(퍼센타일, +2ms  │
# │ 등)로 잡으려 했는데 세션마다 그 값 자체가 달랐다(§9 이슈1 - 90pct도       │
# │ 95pct도 효과 없었고, +2ms 고정값은 오히려 어떤 세션에선 더 나쁘게 만들며   │
# │ 다른 세션에선 필요없었다). 상수를 더 정교하게 다듬는 대신, 스트리밍       │
# │ 도중 실제 사이클을 계속 관찰해서 그 세션의 진짜 상태를 실행 중에 따라간다. │
# │                                                                           │
# │ 방식: 최근 ADAPT_WINDOW개 사이클의 '주기미달 비율'을 ADAPT_CHECK_INTERVAL │
# │ 사이클마다 확인한다. 미달이 잦으면(환경이 나빠짐) 주기를 조금 늘리고,     │
# │ 미달이 거의 없으면(여유가 생김) 원래 계산했던 값 쪽으로 조금 되돌린다.    │
# │                                                                           │
# │ 안전장치:                                                                 │
# │  - calib_period 아래로는 절대 안 내려간다 - 그 값은 정지 상태에서 신중히  │
# │    잰 하한이다. 빨라지는 방향은 딱 거기까지만.                            │
# │  - ADAPT_MAX_FACTOR(calib의 1.6배)를 넘게까지 늘어나면 더 안 늘리고       │
# │    경고만 남긴다 - 무한정 느려지는 건 재보정이 아니라 사실상 멈추는       │
# │    것과 같다. 그 이상은 '이 세션은 환경이 심각하다'는 신호로 다뤄야 한다. │
# │  - 매 사이클이 아니라 ADAPT_CHECK_INTERVAL마다만 판단한다 - deque         │
# │    append는 사실상 무료지만, 판단 자체를 너무 자주 하면 짧은 순간의       │
# │    우연한 튐에도 주기가 씰룩거려(진동) 오히려 더 불안정해진다.            │
# └───────────────────────────────────────────────────────────────────────────┘
ADAPT_WINDOW = 20            # 판단에 쓸 최근 사이클 수
ADAPT_CHECK_INTERVAL = 10    # 몇 사이클마다 한 번씩 판단할지
ADAPT_MISS_HIGH = 0.30       # 이 이상 미달이면 주기를 늘림
ADAPT_MISS_LOW = 0.05        # 이 이하면 원래값 쪽으로 회복 시도
ADAPT_STEP_UP = 1.08         # 늘릴 때 배율 (한 번에 8%)
ADAPT_STEP_DOWN = 0.97       # 되돌릴 때 배율 (더 조심스럽게 - 급히 빨라지면 다시 미달 위험)
ADAPT_MAX_FACTOR = 1.6       # calib_period 대비 최대 배율


def calibrate_dispatch_period(mc, measure_mode, still_angles_deg):
    """[자동 주기 보정] MIN_DISPATCH_PERIOD_SEC를 손으로 맞추는 대신,
    실제로 몇 사이클을 돌려 '이 컴퓨터+이 로봇+지금 선택된 측정모드'
    조합에서 한 사이클이 실제로 얼마나 걸리는지 재고 거기서 주기를 정한다.

    이미 도착해 정지해 있는 좌표(still_angles_deg)를 그대로 다시 보내므로
    로봇은 움직이지 않는다 - 순수하게 통신 왕복 비용만 잰다.

    [지연 FK 적용 후] 스트리밍 루프는 이제 get_angles()만 하고 순기구학은
    나중에 일괄 계산한다. 그래서 캘리브레이션도 get_angles()만 재는 게
    다시 맞다 - 실제 루프가 하는 일과 항상 같은 것을 재야 한다는 원칙은
    그대로다.

    반환: (전송 주기 sec, 실측 사이클 평균 sec, 표준편차 sec)

    [5차 개선, §9 이슈1] 표본 12개(측정모드 'full')는 지터(표준편차)를
    짧은 시간에 다 못 담아서, 최근 실행에서도 주기미달 31%가 관측됐다.
    두 가지를 함께 바꿨다: (1) 표본을 12→48('full')/8→32('none')로 증량,
    (2) 마진 공식을 '평균+1.5*표준편차'에서 90퍼센타일 실측값으로 교체.

    **[6차 - 시도했다 되돌림]** 95퍼센타일도 효과가 없어서(적용주기/실측/
    미달비율이 90퍼센타일 때와 소수점까지 동일) "정지캘리브와 실행중
    평균 사이에 고정 2ms 격차가 있다"고 보고 그 값을 더해봤는데, 세 번째
    실행에서 마진을 올린 만큼 실측 평균도 그대로 같이 올라버렸고 미달
    비율은 오히려 악화됐다(13%→21%). 표본 2개로 성급히 일반화한 판단
    오류였다 - 격차는 고정 상수가 아니라 세션마다(그때그때 USB/시리얼
    상태에 따라) 달라지는 값이었다. 그 수정은 되돌렸다.

    **[6차 재도입 - 이번엔 실시간 적응형]** 고정 상수 대신, 아래
    run_streaming_dispatch()가 실행 중에 직접 관찰하며 주기를 조정한다.
    이 함수(calibrate_dispatch_period)는 여전히 "시작할 때의 합리적인
    출발점"을 정하는 역할만 하고, 세션 중 변동 대응은 적응형 로직이 맡는다.
    """
    n_samples = 48 if measure_mode == "full" else 32   # 'none': 읽기가 없어 사이클이 매우 짧다

    # 워밍업 1회 - 첫 호출의 일회성 오버헤드(캐시 등)가 통계에 섞이지 않게.
    if not fast_send_angles(mc, still_angles_deg, STREAM_SEND_SPEED):
        mc.send_angles(still_angles_deg, STREAM_SEND_SPEED)
    if measure_mode == "full":
        mc.get_angles()

    cycle_times = []
    for _i in range(n_samples):
        t0 = time.perf_counter()
        if not fast_send_angles(mc, still_angles_deg, STREAM_SEND_SPEED):
            mc.send_angles(still_angles_deg, STREAM_SEND_SPEED)
        if measure_mode == "full":
            mc.get_angles()
        cycle_times.append(time.perf_counter() - t0)

    arr = np.array(cycle_times)
    floor_mean = float(arr.mean())
    floor_std = float(arr.std())
    floor_p95 = float(np.percentile(arr, 95))
    period = max(MIN_DISPATCH_PERIOD_SEC, floor_p95 * 1.05)
    return period, floor_mean, floor_std


def run_streaming_dispatch(mc, curve_waypoints, calib_period, apply_correction,
                            measure_mode, t_start,
                            cmd_times, cmd_angles, cmd_targets,
                            stream_meas_times, stream_meas_angles,
                            sample_measurement_raw_fn, log_fn=print):
    """스트리밍(브레이크 없음) 모드의 실시간 전송 루프.

    execute_path()에서 그대로 옮겨온 부분이다 - 실시간 데드라인이 있는 루프라
    안에서 무거운 계산을 하면 안 되고(§ 지연FK 원칙), 그 성질이 GUI 코드와
    섞여있으면 알아보기 어려워서 이 함수 하나로 독립시켰다.

    [부수효과에 대해] cmd_times/cmd_angles/cmd_targets/stream_meas_times/
    stream_meas_angles는 호출자가 만든 리스트를 **그대로 채운다**(새 리스트를
    반환하지 않음) - execute_path()가 이 루프 전후로 같은 리스트를 계속
    이어 쓰기 때문에, 참조를 유지하는 쪽이 자연스럽고 예전 동작과도 100%
    동일하다.

    sample_measurement_raw_fn(stream_meas_times, stream_meas_angles, t_start):
        get_angles()만 읽어서 버퍼에 쌓는 콜백. GUI 클래스(PathEditor)의
        `self._sample_measurement_raw`를 그대로 넘겨받는다 - 이 함수는 로봇
        객체(mc)에 접근해야 하는데, 이 모듈은 mc는 알아도 "PathEditor의 그
        메서드"까지는 몰라야 하므로(그래야 GUI와 무관해진다) 콜백으로 주입받는다.

    log_fn: 적응형 재보정이 조정할 때마다 부를 로그 함수 (기본 print - 콘솔에
        [적응형 재보정] 메시지가 그대로 뜬다. 테스트에서는 리스트에 담는 함수로
        바꿔치기할 수 있다).

    반환: dict(cycle_mean, cycle_std, late_ratio, target_period, adapt_events, calib_period)
    """
    dispatch_period = calib_period
    # [6차 최종] 시작가속램프를 제거했다 - 서로 다른 곡선 2개에서 A/B 비교한
    # 결과 둘 다 램프 ON이 오히려 τ(추종지연)를 늘렸다(280ms vs 180ms, 280ms
    # vs 210ms, 두 번 다 OFF가 이김). "0→목표속도 순간점프가 지연 원인"이라는
    # 가설이 두 번 다 반증됐다 - 램프 구간 자체의 가감속 과도응답이 오히려
    # 새 지연을 만드는 쪽이 맞았다. 그래서 램프 관련 코드(STREAM_RAMP_SEC,
    # STREAM_RAMP_START_FACTOR, GUI 토글)를 전부 걷어내고 처음부터 목표
    # 주기로 등속 전송한다 - 더 단순하고, 더 빠르고(워밍업 구간 없음),
    # 실측으로도 더 낫다는 게 확인됐다.
    cycle_times = []
    cycle_end_abs = []   # [9차, GC 조사] 각 사이클이 끝난 절대시각 (time.time())
    late_count = 0
    # [6차] 적응형 재보정용 상태 - 위 ADAPT_* 상수 설명 참고.
    recent_late = deque(maxlen=ADAPT_WINDOW)
    adapt_since_check = 0
    adapt_events = []        # [(idx, '상향'/'복원', 새주기), ...] - 상태줄/로그용
    adapt_cap_warned = False
    next_t = time.time()
    prev_t = next_t
    # [9차 세션, 전송 리듬 조사] 사이클 리듬의 원인으로 파이썬 GC(가비지컬렉터)를
    # 의심 - 매 사이클 만들어지는 자잘한 리스트(angles_deg 등)가 일정 개수 쌓이면
    # 순환 GC가 주기적으로 발동할 수 있다. gc.callbacks에 콜백을 걸어 "발동
    # 시각"만 관찰한다 - 발동 여부/시점을 바꾸는 게 아니라 기록만 하므로 루프의
    # 실시간 동작 자체에는 영향이 없다(콜백 자체 비용도 리스트 append 1회뿐,
    # 이미 매 사이클 하고 있는 cmd_times.append와 같은 급).
    gc_events = []

    def _on_gc(phase, info):
        if phase == "start":
            gc_events.append(time.time())

    gc.callbacks.append(_on_gc)
    try:
        for idx, (sol, target) in enumerate(curve_waypoints):
            angles_deg = [math.degrees(sol[i]) for i in active_indices]
            # [정지오차 보정] 그래프의 'commanded'는 원래 계획값(angles_deg)을
            # 그대로 쓴다 - 그래야 "보정 덕분에 measured가 얼마나 더 가까워졌는지"
            # 가 그래프에 그대로 드러난다. 로봇에는 보정된 값만 보낸다.
            angles_to_send = (joint_offset_correction(angles_deg)
                              if apply_correction else angles_deg)
            # pymycobot 우회 고속 전송 (30ms -> 0.4ms). 실패하면 안전하게 원래 API로 폴백
            if not fast_send_angles(mc, angles_to_send, STREAM_SEND_SPEED):
                mc.send_angles(angles_to_send, STREAM_SEND_SPEED)

            # 명령값 기록은 통신이 필요 없어 '공짜' - 항상 기록
            cmd_times.append(time.time() - t_start)
            cmd_angles.append(angles_deg)
            cmd_targets.append(list(target))

            # [지연 FK] 실시간 데드라인이 있는 이 루프 안에서는 get_angles()만 하고
            # 저장한다. 순기구학 변환은 나중에(로봇이 멈춘 뒤) 한꺼번에 한다.
            # 정확도는 그대로, 이 루프의 사이클 비용만 줄어든다.
            do_measure = (measure_mode == "full")
            if do_measure:
                sample_measurement_raw_fn(stream_meas_times, stream_meas_angles, t_start)

            next_t += dispatch_period
            sleep_left = next_t - time.time()
            if sleep_left > 0:
                time.sleep(sleep_left)
                was_late = False
            else:
                was_late = True
                late_count += 1
                next_t = time.time()
            now = time.time()
            cycle_times.append(now - prev_t)
            # gc_events와 같은 time.time() 기준의 절대시각 - 나중에 "이 GC 이벤트가
            # 몇 번째 사이클 중에 일어났는가"를 찾을 때 이 배열과 대조한다.
            cycle_end_abs.append(now)

            # [6차] 적응형 재보정 판단.
            recent_late.append(was_late)
            adapt_since_check += 1
            if (adapt_since_check >= ADAPT_CHECK_INTERVAL
                    and len(recent_late) >= min(ADAPT_WINDOW, 10)):
                adapt_since_check = 0
                miss_recent = sum(recent_late) / len(recent_late)
                if miss_recent > ADAPT_MISS_HIGH:
                    cap = calib_period * ADAPT_MAX_FACTOR
                    new_period = min(cap, dispatch_period * ADAPT_STEP_UP)
                    if new_period > dispatch_period + 1e-6:
                        log_fn(f"[적응형 재보정] 최근 미달 {miss_recent*100:.0f}% "
                               f"({len(recent_late)}사이클 중) -> 주기 "
                               f"{dispatch_period*1000:.1f}ms → {new_period*1000:.1f}ms")
                        dispatch_period = new_period
                        adapt_events.append((idx, "상향", dispatch_period))
                        recent_late.clear()   # 새 주기 기준으로 다시 관찰 시작
                    elif not adapt_cap_warned and dispatch_period >= cap - 1e-6:
                        log_fn(f"[적응형 재보정] 상한({cap*1000:.1f}ms, calib의 "
                               f"{ADAPT_MAX_FACTOR}배) 도달 - 더 안 늘립니다. "
                               "환경이 계속 나쁜 것으로 보입니다(USB/시리얼 확인 권장).")
                        adapt_cap_warned = True
                elif miss_recent < ADAPT_MISS_LOW and dispatch_period > calib_period * 1.001:
                    new_period = max(calib_period, dispatch_period * ADAPT_STEP_DOWN)
                    if new_period < dispatch_period - 1e-6:
                        log_fn(f"[적응형 재보정] 최근 미달 {miss_recent*100:.0f}% (여유있음) "
                               f"-> 주기 {dispatch_period*1000:.1f}ms → {new_period*1000:.1f}ms "
                               "(원래값 쪽으로 회복)")
                        dispatch_period = new_period
                        adapt_events.append((idx, "복원", dispatch_period))
                        recent_late.clear()
            prev_t = now

        # [9차, GC 조사] 관찰이 끝났으니 콜백을 반드시 해제한다 - 안 지우면
        # 다음 실행 때 또 append돼서 콜백이 중첩되고, gc_events에 이번 실행과
        # 무관한 이벤트까지 섞여 들어간다.
    finally:
        # [9차, GC 조사] 루프 중간에 예외(로봇 통신 오류 등)가 나도
        # 콜백이 남지 않도록 반드시 여기서 해제한다.
        gc.callbacks.remove(_on_gc)

    if cycle_times:
        arr = np.array(cycle_times)
        cycle_mean = float(arr.mean())
        cycle_std = float(arr.std())
    else:   # 웨이포인트가 0개였던 극단적인 경우
        cycle_mean = cycle_std = 0.0
    late_ratio = late_count / max(1, len(curve_waypoints))

    return {
        "cycle_mean": cycle_mean,
        "cycle_std": cycle_std,
        "late_ratio": late_ratio,
        "target_period": dispatch_period,    # 적응형 조정이 있었다면 최종값이 반영됨
        "adapt_events": adapt_events,
        "calib_period": calib_period,
        # [9차 세션, 전송 리듬 조사] 원본 시계열을 그대로 얹는다.
        # mycobot_cycle_log.py가 저장하고 mycobot_cycle_rhythm_diagnostic.py가 분석한다.
        "cycle_times": cycle_times,
        # [9차, GC 조사] GC 발동 절대시각과 사이클별 종료 절대시각 - 이 둘을
        # 대조하면 "몇 번째 사이클에 GC가 끼었는가"를 알 수 있다.
        "gc_events": gc_events,
        "cycle_end_abs": cycle_end_abs,
    }
